#!/bin/bash
# ==============================
# Data Science Academy
# Script: script1.sh
# ==============================
TEXTO="Hello World"
echo $TEXTO
