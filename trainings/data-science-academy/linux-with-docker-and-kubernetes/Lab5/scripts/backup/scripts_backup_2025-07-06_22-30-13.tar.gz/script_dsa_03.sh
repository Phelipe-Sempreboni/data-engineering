#!/bin/bash
# ==============================
# Data Science Academy
# Script: script3.sh
# ==============================

clear
echo "Detalhes do Ambiente Linux:"
echo "================================================"
echo ""
echo "Sua pasta home é: $HOME"
echo ""
echo "O nome desta máquina é: $HOSTNAME"
echo ""
echo "Seu tipo de sessão terminal é: $TERM"
echo ""
echo "O PATH é: $PATH"
echo ""